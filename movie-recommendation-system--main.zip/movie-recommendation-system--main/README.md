![Screenshot 2024-10-26 114702](https://github.com/user-attachments/assets/bdd5a3a7-2a1b-4d8d-8315-c0429016f795)

# movie-recommendation-system-
I had developed a movie recommendation system that allows users to input a genre and receive the highest-rated movie within that genre. Leveraging a comprehensive movie dataset, the system efficiently filters and ranks movies by genre to provide an optimal recommendation based on user preferences.
